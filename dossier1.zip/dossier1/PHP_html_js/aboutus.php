<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">




  <title>About us</title>






  <link rel="stylesheet" href="http://localhost/dossier1/CSS/aboutus.css">


</head>

<body>


  <!-- Page Content -->
  <!-- About Page Starts Here -->


  <h1 class="ab">About Us</h1>

  <img class="img" src="Images/about.png" alt="">


  <h4 class=" titre">À propos de nous</h4>

  <p class="aboutus">SHOP LINE est une société internationale de commerce électronique . La société se spécialise principalement dans le prêt-à-porter pour femme, mais elle propose également des vêtements pour hommes, des accessoires, des chaussures, des sacs et d’autres articles de mode.</p>
  <p class="aboutus"> SHOP LINE est fier d'offrir aux femmes et adolescentes l'opportunité de s'offrir les dernières tendances à prix démocratiques. </p>
  <p class="aboutus"> SHOP LINE adhère au concept selon lequel "tout le monde doit être en mesure d'apprécier la beauté de la mode". Shop line ne manque jamais les dernières tendances des quatre coins du globe et se charge de rapidement les lancer sur le marché. SHOP LINE expédie dans plus de 150 pays et territoires du monde entier maintenant. Notre site Web est disponible pour les États-Unis, l'Espagne, la France, la Russie, l'Allemagne, l'Italie, l'Australie et le Moyen Orient. Nos colis sont expédiés depuis divers entrepôts situés à différents points stratégiques. SHOP LINE ne cesse de grandir, en partie grâce à ses valeurs selon lesquelles la production interne doit faire preuve d'une excellence indiscutable. Shop line a pour objectif de proposer des articles tendance de haute qualité tout en proposant un service irréprochable.</p>




  <!-- Sub Footer Starts Here -->
  <Footer>
    <p>Copyright &copy; 2022 online shop </p>
  </footer>




</body>

</html>