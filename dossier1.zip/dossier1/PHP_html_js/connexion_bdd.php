<?php

$database_name = "ecommerce";
$cnx = mysqli_connect("localhost", "root", "", $database_name);
