<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">


    <link rel="stylesheet" href="http://localhost/dossier1/CSS/style.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
    <title>SHOP_LINE</title>
</head>

<body>

    <div>
        <div class="header-dark">
            <nav class="navbar navbar-dark navbar-expand-md navigation-clean-search">
                <div class="container">
                    <a class="navbar-brand">ONline Shop</a>
                    <button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1">
                        <span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navcol-1">
                        <ul class="nav navbar-nav">
                            <li class="nav-item" role="presentation"><a class="nav-link" href="acceuil.php">Home</a></li>
                            <li class="dropdown"><a class="dropdown-toggle nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#">Categories </a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="femme.php">FEMME</a>
                                    <a class="dropdown-item" href="homme.php">HOMME</a>
                            </li>
                        </ul>
                        <form class="form-inline mr-auto" target="_self">
                            <div class="form-group"><label for="search-field"><i class="fa fa-search"></i></label><input class="form-control search-field" type="search" name="search" id="search-field"></div>
                        </form><span class="navbar-text"><a href="seconnecter.php" class="seconnecter.php">Log In</a></span><a class="btn btn-light action-button" role="button" href="sinscrire.php">Sign Up</a>
                    </div>

                </div>
            </nav>
            <section-contact>
                <form>
                    <h1>Contactez-nous</h1>

                    <div class="corps-formulaire">
                        <div class="gauche">
                            <div class="groupe">
                                <label>Votre Prénom</label>
                                <input type="text" placeholder="Your name" />

                            </div>
                            <div class="groupe">
                                <label>Votre adresse e-mail</label>
                                <input type="text" placeholder="Your Email" />

                            </div>
                            <div class="groupe">
                                <label>Votre téléphone</label>
                                <input type="text" placeholder="Your phone" />

                            </div>
                        </div>

                        <div class="droite">
                            <div class="groupe">
                                <label>Message</label>
                                <textarea placeholder="Saisissez ici..."></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="pied-formulaire" align="center">
                        <button>Envoyer le message</button>
                    </div>
                </form>
            </section-contact>
</body>

</html>