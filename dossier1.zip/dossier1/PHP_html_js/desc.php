<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">

    <title> Product Detail</title>

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="desc.css">

</head>

<body>

    <!-- Page Content -->
    <!-- Single Starts Here -->
    <div class="single-product">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-heading">
                        <div class="line-dec"></div>
                        <h1>Single Product</h1>
                    </div>
                </div>
                <div class="img">
                    <img src="big-04.jpg">
                </div>

                <!-- description -->
                <div class="desc">
                    <div class="right-content">
                        <h4>Single Product Name</h4>
                        <h6>$55.00</h6>
                        <p>Lorem ipsum dolor sit amet, consectetur Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid dolore architecto voluptate unde. Quia quam rem architecto fuga optio facilis consectetur vitae, inventore sed atque assumenda quasi! Quidem, esse vero? adipisicing elit. Aliquid dolore architecto voluptate unde. Quia quam rem architecto fuga optio facilis consectetur vitae, inventore sed atque assumenda quasi! Quidem, esse vero?</p>
                        <span>7 left on stock</span>
                        <form action="" method="get">
                            <label for="quantity">Quantity:</label>
                            <input name="quantity" type="number" min="1" max="10" class="quantity-text" id="quantity" value="1">
                            <input type="submit" class="button" value="Order Now!">
                        </form>
                        <div class="down-content">
                            <div class="categories">
                                <h6>Category: <span><a href="#">Women</a>,<a href="#">jean</a>,<a href="#">product </a></span></h6>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



</body>

</html>