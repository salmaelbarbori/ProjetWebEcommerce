<?php
session_start();
$database_name = "ecommerce";
$cnx = mysqli_connect("localhost", "root", "", $database_name);

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SHOP_LINE</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <link rel="stylesheet" href="http://localhost/dossier1/CSS/femme.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <div>
        <div class="header-dark">
            <nav class="navbar navbar-dark navbar-expand-md navigation-clean-search">
                <div class="container">
                    <a class="navbar-brand">ONline Shop</a>
                    <button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1">
                        <span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navcol-1">
                        <ul class="nav navbar-nav">
                            <li class="nav-item" role="presentation"><a class="nav-link" href="Contact.php">Contact Us</a></li>
                            <li class="dropdown"><a class="dropdown-toggle nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#">Categories </a>
                                <div class="dropdown-menu" role="menu">
                                    <a class="dropdown-item" href="femme.php">FEMME</a>
                                    <a class="dropdown-item" href="homme.php">HOMME</a>
                            </li>
                        </ul>
                        <form class="form-inline mr-auto" target="_self">
                            <div class="form-group"><label for="search-field"><i class="fa fa-search"></i>
                                </label><input class="form-control search-field" type="search" name="search" id="search-field"></div>
                        </form><span class="navbar-text"><a href="seconnecter.php" class="login">Log In</a></span>
                        <a class="btn btn-light action-button" role="button" href="sinscrire.php">Sign Up</a>
                    </div>
                    <a href=""></a>



                </div>
            </nav>


            <!--Section Avant article-->
            <section id="container0" class="section0">
                <h1 class="title">Votre elegance commence <strong>Chez Nous</strong></h1>
            </section>

            <!--1ere ligne-->
            <div class="container1">
                <?php
                $query = "SELECT * FROM produit WHERE id IN(21,22,23); ";
                $resultat = mysqli_query($cnx, $query);
                if (mysqli_num_rows($resultat) > 0) {
                    while ($row = mysqli_fetch_array($resultat)) {
                ?>
                        <form method="post" action="panier.php?action=ajouter&id=<?php echo $row["id"]; ?>">
                            <div class="produit1">
                                <img class="image" src="<?php echo $row["image"]; ?>" height="170">
                                <h5 class="titre5"><?php echo $row["nom"] ?></h5>
                                <h5 class="titre5">Prix :<?php echo $row["prix"] ?>MAD</h5>
                                <input type="text" name="quantite" class="form-control" placeholder="quantite">
                                <input type="hidden" name="nom_cache" value="<?php echo $row["nom"]; ?>">
                                <input type="hidden" name="prix_cache" value="<?php echo $row["prix"]; ?>">
                                <input type="submit" name="ajouter" value="Ajouter a la carte">
                            </div>
                        </form>

                <?php
                    }
                } ?>
            </div>

</body>

</html>