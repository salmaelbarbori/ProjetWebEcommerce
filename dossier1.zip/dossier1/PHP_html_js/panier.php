<!-- traitement php-->
<?php
session_start();
$database_name = "ecommerce";
$con = mysqli_connect("localhost", "root", "", $database_name);


if (isset($_POST["ajouter"])) {
    if (isset($_SESSION["cart"])) {
        $table_produit_id = array_column($_SESSION["cart"], "sid");
        if (!in_array($_GET["id"], $table_produit_id)) {
            $count = count($_SESSION["cart"]);
            $table_produit = array(
                'id_produit' => $_GET["id"],
                'nom_produit' => $_POST["nom_cache"],
                'prix_produit' => $_POST["prix_cache"],
                'quantite_produit' => $_POST["quantite"],
            );
            $_SESSION["cart"][$count] = $table_produit;
            echo '<script>window.location="panier.php"</script>';
        } else {
            echo '<script>alert("Produit ajoute")</script>';
            echo '<script>window.location="panier.php"</script>';
        }
    } else {
        $table_produit = array(
            'id_produit' => $_GET["id"],
            'nom_produit' => $_POST["nom_cache"],
            'prix_produit' => $_POST["prix_cache"],
            'quantite_produit' => $_POST["quantite"],
        );
        $_SESSION["cart"][0] = $table_produit;
    }
}

if (isset($_GET["action"])) {
    if ($_GET["action"] == "supprimer") {
        foreach ($_SESSION["cart"] as $keys => $value) {
            if ($value["id_produit"] == $_GET["id"]) {
                unset($_SESSION["cart"][$keys]);
                echo '<script>alert("Produit supprime!")</script>';
                echo '<script>window.location="panier.php"</script>';
            }
        }
    }
}
?>

?>
<style>
    .container {
        width: 100%;
        justify-content: center;
    }

    table,
    th,
    tr {
        text-align: center;
    }

    table th {
        background-color: #efefef;
    }
</style>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SHOP_LINE</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <link rel="stylesheet" href="http://localhost/dossier1/CSS/femme.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <div>
        <div class="header-dark">
            <nav class="navbar navbar-dark navbar-expand-md navigation-clean-search">
                <div class="container">
                    <a class="navbar-brand">ONline Shop</a>
                    <button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1">
                        <span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navcol-1">
                        <ul class="nav navbar-nav">
                            <li class="nav-item" role="presentation"><a class="nav-link" href="Contact.html">Contact Us</a></li>
                            <li class="dropdown"><a class="dropdown-toggle nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#">Categories </a>
                                <div class="dropdown-menu" role="menu">
                                    <a class="dropdown-item" href="femme.php">FEMME</a>
                                    <a class="dropdown-item" href="homme.php">HOMME</a>
                            </li>
                        </ul>
                        <form class="form-inline mr-auto" target="_self">
                            <div class="form-group"><label for="search-field"><i class="fa fa-search"></i>
                                </label><input class="form-control search-field" type="search" name="search" id="search-field"></div>
                        </form><span class="navbar-text"><a href="#" class="login">Log In</a></span>
                        <a class="btn btn-light action-button" role="button" href="#">Sign Up</a>
                    </div>
                    <a href=""></a>
                </div>
            </nav>
            <!--partie panier-->
            <div class="container">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <tr>
                            <th width="30%">Nom produit</th>
                            <th width="10%">Quantite</th>
                            <th width="13%">Prix unitaire</th>
                            <th width="10%">Prix total</th>
                            <th width="17%">Supprimer</th>
                        </tr>

                        <?php
                        if (!empty($_SESSION["cart"])) {
                            $total = 0;
                            foreach ($_SESSION["cart"] as $key => $value) {
                        ?>
                                <tr>
                                    <td><?php echo $value["nom_produit"]; ?></td>
                                    <td><?php echo $value["quantite_produit"]; ?></td>
                                    <td>$ <?php echo $value["prix_produit"]; ?></td>
                                    <td>
                                        $ <?php echo number_format($value["quantite_produit"] * $value["prix_produit"], 2); ?></td>
                                    <td><a href="panier.php?action=supprimer&id=<?php echo $value["id_produit"]; ?>"><span class="text-danger">Supprimer produit</span></a></td>

                                </tr>
                            <?php
                                $total = $total + ($value["quantite_produit"] * $value["prix_produit"]);
                            }
                            ?>
                            <tr>
                                <td colspan="3" align="right"> Prix Total</td>
                                <th align="right">$ <?php echo number_format($total, 2); ?></th>
                                <td></td>
                            </tr>
                        <?php
                        }
                        ?>
                    </table>
                </div>

            </div>

</body>

</html>