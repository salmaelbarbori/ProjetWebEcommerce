







<?php
include "connexion_bdd.php";
if (isset($_POST['submit'])) {
    if (isset($_POST['nom'])  && isset($_POST['motpasse'])) {
        if (!empty($_POST['nom']) && !empty($_POST['motpasse'])) {
            //echo 'Bienvenue dasns votre espace';
            $nom = $_POST['nom'];

            $motpasse = $_POST['motpasse'];
            $sql = "INSERT INTO  seconnecter (nom,motpasse) VALUES ('$nom','$motpasse')";
            $cnx->query($sql);
        }
    }
}
?>