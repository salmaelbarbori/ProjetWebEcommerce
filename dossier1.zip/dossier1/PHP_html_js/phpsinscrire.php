




<?php
include "connexion_bdd.php";
if (isset($_POST['submit'])) {
    if (isset($_POST['nom']) && isset($_POST['prenom']) && isset($_POST['Email']) && isset($_POST['motpasse'])) {
        if (!empty($_POST['nom']) && !empty($_POST['prenom']) && !empty($_POST['Email']) && !empty($_POST['motpasse'])) {
            //echo 'Bienvenue dasns votre espace';
            $nom = $_POST['nom'];
            $prenom = $_POST['prenom'];
            $email = $_POST['Email'];
            $motpasse = $_POST['motpasse'];
            $sql = "INSERT INTO  sinscrire (nom,prenom,Email,motpasse) VALUES ('$nom','$prenom','$email','$motpasse')";
            $cnx->query($sql);
        }
    }
}
?>