<?php
if (isset($_POST['boutton'])) {
    if (isset($_POST['nom']) && isset($_POST['prenom']) && isset($_POST['Email']) && isset($_POST['password'])) {
        if (!empty($_POST['nom']) && !empty($_POST['prenom']) && !empty($_POST['Email']) && !empty($_POST['password'])) {
            //echo 'Bienvenue dans votre espace';
            $nom = $_POST['nom'];
            $prenom = $_POST['prenom'];
            $email = $_POST['Email'];
            $password = $_POST['password'];
            $sql = "INSERT INTO `sinscrire` VALUES ('$nom','$prenom','$email','$password')";
        }
    }
}
