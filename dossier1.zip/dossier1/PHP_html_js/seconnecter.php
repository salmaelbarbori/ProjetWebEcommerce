<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>Formulaire dinscrption</title>


    <link rel="stylesheet" href="http://localhost/dossier1/CSS/styleseconnecter.css" />

</head>

<body>

    <body>


        <div class="container">
            <form action="phpseconnecter.php" method="POST" id="form">
                <div class="titre" color="violet"> Creer un compte</div>
                <div class="form_input">
                    <div class="class1">
                        <input type="text" id="nom" name="nom" placeholder="login" required>
                        <span class="err" id="nomerr">6 char minimum </span>
                    </div>

                    <div class="class4">
                        <input type="password" id="motpasse" name="motpasse" placeholder="motpasse" required>
                        <span class="err" id="passerr">6 char minimum </span>
                    </div>
                    <div class="class5">

                        <input type="submit" id="submit" name="submit" value="se connecter" placeholder="Valider">
                        <a href="acceuil.php">BACK TO HOME</a>

                    </div>

                </div>
            </form>
        </div>


    </body>

</html>


















</html>