<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        @import url("https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap");

        body {
            background: url('https://www.shutterstock.com/image-vector/online-shopping-concept-perfect-landing-page-1654537690') #444;
            background-size: cover;
            padding-bottom: 80px;
            border-radius: 4px;
            margin: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-items: center;
            font-size: 18px;
            background-size: cover;
            justify-content: center;
        }

        .titre {
            color: rgb(54, 59, 65);
            font-size: 30px;
            font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;
            align-items: center;
            justify-content: center;
            justify-items: center;
            text-align: center;
        }

        .container {
            margin: 1rem;
            box-shadow: 0 0 40px rgba(71, 33, 33, 0.2);
            border-radius: 2px;
            background-color: rgb(240, 222, 222);
            padding: 2rem;
            width: 400px;
            max-width: 400px;


        }

        input[type=text] {
            display: block;
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            box-sizing: border-box;
            box-shadow: 1rem;
        }

        input[type=password] {
            display: block;
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0px;
            box-sizing: border-box;
            box-shadow: 1rem;
        }

        input[type=submit] {
            display: block;
            width: 70%;
            padding: 12px 20px;
            margin: auto;
            background-color: rgb(184, 177, 174);
            border: 0.2px solid rbga(0.2, 0.2, 0.2, 0.2);
            font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;
        }

        .err {
            display: none;
        }
    </style>
    <title>Formulaire dinscrption</title>
</head>

<body>


    <div class="container">
        <form action="phpsinscrire.php" method="POST" id="form">
            <div class="titre" color="violet"> Creer un compte</div>
            <div class="form_input">
                <div class="class1">
                    <input type="text" id="nom" name="nom" placeholder="nom" required>

                    <b class="err" id="nomerr">6 char minimum</b>
                </div>
                <div class="class2">
                    <input type="text" id="prenom" name="prenom" placeholder="preom" required>
                    <b class="err" id="prenomerr">6 char minimum</b>
                </div>
                <div class="class3">
                    <input type="text" id="Email" name="Email" placeholder="email" required>

                </div>
                <div class="class4">
                    <input type="password" id="motpasse" name="motpasse" placeholder="motpasse" required>
                    <b class="err" id="passworderr">6 char minimum</b>
                </div>
                <div class="class5">
                    <input type="submit" id="submit" name="submit" value="S'inscrire" placeholder="Valider">
                    <a href="acceuil.php">BACK TO HOME</a>
                </div>
            </div>
        </form>
    </div>




    <script>
        /*
        const form = document.getElementById("form");

        form.addEventListener("submit", formValidation);

        function formValidation(event) {
            event.preventDefault()




            // Validation nom
            let nom = document.getElementById("nom")
            let nomValide = false
            if (nom.value.length >= 6) {
                nomValide = true
            }
            if (nomValide) {
                document.getElementById("nomerr").style.display = "none";
            } else {
                document.getElementById("nomerr").style.display = "initial";
            }

            // Validation prenom
            let prenom = document.getElementById("prenom")
            let prenomValide = false
            if (prenom.value.length >= 2) {
                prenomValide = true
            }
            if (prenomValide) {
                document.getElementById("prenomerr").style.display = "none";
            } else {
                document.getElementById("prenomerr").style.display = "initial";
            }





            // Validation mdp
            let mdp = document.getElementById("motpasse")
            let mdpValide = false
            if (mdp.value.length >= 6) {
                mdpValide = true
            }
            if (mdpValide) {
                document.getElementById("passworderr").style.display = "none";
            } else {
                document.getElementById("passworderr").style.display = "initial";
            }


        }*/
    </script>


</body>

</html>